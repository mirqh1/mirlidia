for (let i = 1; i <= 10; i++){
    document.write(i+' ')
}
var sum = 0;
        for (var i = 1; i <= 50; i++) {
            sum += i;
         }
        alert(sum);

        for (let i = 1; i <= 20; i++) {
            if (i % 2 == 0) {
              alert( i );
            }
          }
        for (let i = 10; i >= 1; i--) {
            document.write(i- '')
        }
        for (i =0; 1 < 10; 1++) {
            document.write ('<li>5 * ' + 1 + '=' + s * i + '</li>')
        }